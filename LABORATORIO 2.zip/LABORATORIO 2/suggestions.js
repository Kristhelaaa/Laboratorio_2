let suggestions = [
	'Fresas con crema',
	'Frutas tropicales',
	'Chocolat cake',
	'Pastel de galleta',
	'Saint Hinchoré',
	'Selva negra',
	'California',
	'Capricho',
];